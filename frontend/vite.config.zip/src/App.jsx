import React, { Suspense, lazy } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./contexts/AuthContext";
import ProtectedRoute from "./components/ProtectedRoute";
import AdminPanel from "./pages/admin/AdminPanel";

// Pages (lazy loading)
const LoginPage = lazy(() => import("./pages/auth/LoginPage.jsx"));
const RegisterPage = lazy(() => import("./pages/auth/RegisterPage.jsx"));
const CompanyPage = lazy(() => import("./pages/company/CompanyPage.jsx"));
const DashboardPage = lazy(() => import("./pages/dashboard/DashboardPage.jsx"));
const Loading = lazy(() => import("./pages/dashboard/Loading.jsx"));
const MyApplicationsPage = lazy(() => import("./pages/my-application/MyApplicationsPage.jsx"));
const MyTrackPage = lazy(() => import("./pages/my-track/MyTrackPage.jsx"));
const ProfilePage = lazy(() => import("./pages/profile/ProfilePage.jsx"));
const SetupPage = lazy(() => import("./pages/setup/SetupPage.jsx"));
const SubmitExperiencePage = lazy(() => import("./pages/submit-experience/SubmitExperiencePage.jsx"));

// Optional: a fallback component for suspense
function Loader() {
  return <div className="p-6 text-center">Loading...</div>;
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Suspense fallback={<Loader />}>
          <Routes>
            {/* Auth Routes */}
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />

            {/* Dashboard / Main Routes */}
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/loading" element={<Loading />} />

            {/* Company - Protected Route */}
            <Route 
              path="/company/:id" 
              element={
                <ProtectedRoute>
                  <CompanyPage />
                </ProtectedRoute>
              } 
            />

            {/* My Applications - Protected */}
            <Route 
              path="/my-applications" 
              element={
                <ProtectedRoute>
                  <MyApplicationsPage />
                </ProtectedRoute>
              } 
            />

            {/* My Track - Protected */}
            <Route 
              path="/my-track" 
              element={
                <ProtectedRoute>
                  <MyTrackPage />
                </ProtectedRoute>
              } 
            />

            {/* Profile - Protected */}
            <Route 
              path="/profile" 
              element={
                <ProtectedRoute>
                  <ProfilePage />
                </ProtectedRoute>
              } 
            />

            {/* Setup - Protected */}
            <Route 
              path="/setup" 
              element={
                <ProtectedRoute>
                  <SetupPage />
                </ProtectedRoute>
              } 
            />

            {/* Submit Experience - Protected */}
            <Route 
              path="/submit-experience" 
              element={
                <ProtectedRoute>
                  <SubmitExperiencePage />
                </ProtectedRoute>
              } 
            />

            <Route path="/adminpanel"
              element={
                <ProtectedRoute adminOnly={true}>
                  <div className="p-6 text-center"><AdminPanel/></div>
                </ProtectedRoute>
              }
            />

            {/* Default route */}
            <Route path="/" element={<Navigate to="/dashboard" replace />} />

            {/* 404 Not Found */}
            <Route path="*" element={<div className="p-6 text-center text-red-500">404 - Page Not Found</div>} />
          </Routes>
        </Suspense>
      </Router>
    </AuthProvider>
  );
}