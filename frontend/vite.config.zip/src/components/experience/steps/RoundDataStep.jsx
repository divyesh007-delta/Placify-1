import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import CodingForm from "../forms/CodingForm";
import { TechnicalForm } from "../forms/TechnicalForm";
import { HRForm } from "../forms/HRForm";
import { GDForm } from "../forms/GDForm";
import AptitudeForm from "../forms/AptitudeForm";

export  function RoundDataStep({ data, onUpdate, onNext, onBack }) {
  const handleRoundDataUpdate = (roundName, roundData) => {
    const updatedRoundsData = {
      ...data.roundsData,
      [roundName]: roundData
    };
    onUpdate({ roundsData: updatedRoundsData });
  };

  const renderRoundForm = (roundName) => {
    const roundData = data.roundsData[roundName] || {};
    
    const formProps = {
      data: roundData,
      onUpdate: (updatedData) => handleRoundDataUpdate(roundName, updatedData)
    };

    switch (roundName) {
      case "Coding":
        return <CodingForm {...formProps} />;
      case "Technical":
        return <TechnicalForm {...formProps} />;
      case "HR":
        return <HRForm {...formProps} />;
      case "Group Discussion":
        return <GDForm {...formProps} />;
      case "Aptitude":
        return <AptitudeForm {...formProps} />;
      default:
        return <div>Form for {roundName} not implemented</div>;
    }
  };

  const canProceed = () => {
    // Check if all selected rounds have at least some data
    return data.selectedRounds.every(round => 
      data.roundsData[round] && Object.keys(data.roundsData[round]).length > 0
    );
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Round Details</CardTitle>
        <p className="text-sm text-muted-foreground">
          Provide detailed information for each selected round
        </p>
      </CardHeader>
      <CardContent>
        <div className="space-y-8">
          {data.selectedRounds.map((roundName, index) => (
            <div key={roundName} className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 bg-primary text-primary-foreground rounded-full text-sm flex items-center justify-center">
                  {index + 1}
                </div>
                <h3 className="text-lg font-semibold">{roundName} Round</h3>
              </div>
              {renderRoundForm(roundName)}
              {index < data.selectedRounds.length - 1 && <hr />}
            </div>
          ))}
        </div>

        <div className="flex justify-between mt-8">
          <Button variant="outline" onClick={onBack}>
            Back
          </Button>
          <Button onClick={onNext} disabled={!canProceed()}>
            Continue to Review
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}