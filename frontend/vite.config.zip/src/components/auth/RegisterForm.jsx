import React, { useState } from "react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Eye, EyeOff, Mail, Lock, User, Phone, IdCard } from "lucide-react";
import api from "../../services/api"

export default function RegisterForm() {
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    studentId: "",
    fullName: "",
    phone: ""
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [id]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await api.post("/auth/register", {
        email: formData.email,
        password: formData.password,
        studentId: formData.studentId,
        fullName: formData.fullName,
        phone: formData.phone
      });

      if (response.data.success) {
        alert("✅ " + response.data.message);
        // Store tokens if provided
        if (response.data.access_token) {
          localStorage.setItem("access_token", response.data.access_token);
          localStorage.setItem("refresh_token", response.data.refresh_token);
        }
        setTimeout(() => { 
          window.location.href = response.data.redirect_url || "/setup"; 
        }, 1000);
      } else {
        alert("❌ " + response.data.message);
      }
    } catch (error) {
      alert("❌ " + (error.response?.data?.message || "Server error"));
    } finally {
      setIsLoading(false);
    }
  };
 
  
  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {/* Student ID Field */}
      <div className="space-y-2">
        <Label htmlFor="studentId">Student ID</Label>
        <div className="relative">
          <IdCard className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input 
            id="studentId" 
            type="text" 
            placeholder="Enter your student ID" 
            value={formData.studentId} 
            onChange={handleChange} 
            className="pl-10" 
            required 
          />
        </div>
      </div>

      {/* Full Name Field */}
      <div className="space-y-2">
        <Label htmlFor="fullName">Full Name</Label>
        <div className="relative">
          <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input 
            id="fullName" 
            type="text" 
            placeholder="Enter your full name" 
            value={formData.fullName} 
            onChange={handleChange} 
            className="pl-10" 
            required 
          />
        </div>
      </div>

      {/* Email Field */}
      <div className="space-y-2">
        <Label htmlFor="email">College Email</Label>
        <div className="relative">
          <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input 
            id="email" 
            type="email" 
            placeholder="22cp059@bvmengineering.ac.in" 
            value={formData.email} 
            onChange={handleChange} 
            className="pl-10" 
            required 
          />
        </div>
      </div>

      {/* Phone Number Field */}
      <div className="space-y-2">
        <Label htmlFor="phone">Phone Number</Label>
        <div className="relative">
          <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input 
            id="phone" 
            type="tel" 
            placeholder="Enter your phone number" 
            value={formData.phone} 
            onChange={handleChange} 
            className="pl-10" 
            required 
          />
        </div>
      </div>

      {/* Password Field */}
      <div className="space-y-2">
        <Label htmlFor="password">Password</Label>
        <div className="relative">
          <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input 
            id="password" 
            type={showPassword ? "text" : "password"} 
            placeholder="Enter your password" 
            value={formData.password} 
            onChange={handleChange} 
            className="pl-10 pr-10" 
            required 
          />
          <Button 
            type="button" 
            variant="ghost" 
            size="sm" 
            className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent" 
            onClick={() => setShowPassword(!showPassword)} 
          >
            {showPassword ? (
              <EyeOff className="h-4 w-4 text-muted-foreground" />
            ) : (
              <Eye className="h-4 w-4 text-muted-foreground" />
            )}
          </Button>
        </div>
        <p className="text-xs text-muted-foreground">
          Password must be at least 6 characters long
        </p>
      </div>

      <Button type="submit" className="w-full" disabled={isLoading}>
        {isLoading ? "Creating account..." : "Sign Up"}
      </Button>
    </form>
  );
}