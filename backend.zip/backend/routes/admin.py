from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity
from bson.objectid import ObjectId
from datetime import datetime
import uuid

admin_bp = Blueprint("admin", __name__)

# ========================= ADMIN MIDDLEWARE =========================


def is_admin(user_id):
    """Check if user is admin"""
    try:
        db = current_app.config["MONGO_DB"]
        user = db.users.find_one({"userId": user_id})
        return user and user.get("role") == "admin"
    except Exception as e:
        current_app.logger.error(f"Admin check error: {str(e)}")
        return False

# ========================= CREATE COMPANY =========================


@admin_bp.route("/admin/companies", methods=["POST"])
@jwt_required()
def create_company():
    try:
        current_user = get_jwt_identity()

        # Check if user is admin
        # if not is_admin(current_user):
        #     return jsonify({"success": False, "message": "Admin access required"}), 403

        data = request.get_json()

        # Validate required fields
        required_fields = ["name", "description", "location"]
        for field in required_fields:
            if field not in data:
                return jsonify({"success": False, "message": f"Missing required field: {field}"}), 400

        # Generate company ID
        company_id = str(uuid.uuid4())

        # Create company document
        company_data = {
            "companyId": company_id,
            "name": data["name"],
            "logo": data.get("logo", ""),
            "description": data["description"],
            "location": data["location"],
            "founded": data.get("founded", ""),
            "employees": data.get("employees", ""),
            "website": data.get("website", ""),
            "tags": data.get("tags", []),

            # Initialize with default values
            "rating": 0.0,
            "experienceCount": 0,

            # Stats with default values
            "stats": {
                "successRate": 0,
                "totalHired": 0,
                "avgPackage": 0,
                "difficulty": "Medium",
                "highestPackage": 0,
                "thisYearHires": 0
            },

            # Job roles
            "jobRoles": data.get("jobRoles", []),

            # Initialize empty analytics
            "roundsAnalytics": {
                "aptitude": {
                    "passRate": 0,
                    "avgScore": 0.0,
                    "totalQuestions": 0,
                    "difficulty": "Medium",
                    "timeLimit": "",
                    "topics": [],
                    "sampleQuestions": [],
                    "count": 0
                },
                "coding": {
                    "passRate": 0,
                    "avgScore": 0.0,
                    "totalQuestions": 0,
                    "difficulty": "Medium",
                    "timeLimit": "",
                    "topics": [],
                    "sampleQuestions": [],
                    "count": 0
                },
                "technical": {
                    "passRate": 0,
                    "avgScore": 0.0,
                    "totalQuestions": 0,
                    "difficulty": "Medium",
                    "timeLimit": "",
                    "topics": [],
                    "sampleQuestions": [],
                    "count": 0
                },
                "hr": {
                    "passRate": 0,
                    "avgScore": 0.0,
                    "totalQuestions": 0,
                    "difficulty": "Medium",
                    "timeLimit": "",
                    "topics": [],
                    "sampleQuestions": [],
                    "count": 0
                },
                "groupdiscussion": {
                    "passRate": 0,
                    "avgScore": 0.0,
                    "totalQuestions": 0,
                    "difficulty": "Medium",
                    "timeLimit": "",
                    "topics": [],
                    "sampleQuestions": [],
                    "count": 0
                }
            },

            # Initialize empty insights
            "insights": {
                "keySkills": [],
                "preparationTips": [],
                "recentTrends": []
            },

            # Initialize empty placed students
            "placedStudents": [],

            # Timestamps
            "createdAt": datetime.utcnow(),
            "updatedAt": datetime.utcnow(),

            # Created by
            "createdBy": current_user
        }

        db = current_app.config["MONGO_DB"]
        result = db.companies.insert_one(company_data)

        return jsonify({
            "success": True,
            "message": "Company created successfully",
            "companyId": company_id
        }), 201

    except Exception as e:
        current_app.logger.error(f"Create company error: {str(e)}")
        return jsonify({"success": False, "message": "Internal server error"}), 500

# ========================= UPDATE COMPANY =========================


@admin_bp.route("/admin/companies/<company_id>", methods=["PUT"])
@jwt_required()
def update_company(company_id):
    try:
        current_user = get_jwt_identity()

        # Check if user is admin
        if not is_admin(current_user):
            return jsonify({"success": False, "message": "Admin access required"}), 403

        data = request.get_json()
        db = current_app.config["MONGO_DB"]

        # Find company
        company = db.companies.find_one({
            "$or": [
                {"companyId": company_id},
                {"_id": ObjectId(company_id) if ObjectId.is_valid(
                    company_id) else None}
            ]
        })

        if not company:
            return jsonify({"success": False, "message": "Company not found"}), 404

        # Update fields
        update_data = {}
        updatable_fields = [
            "name", "logo", "description", "location", "founded",
            "employees", "website", "tags", "jobRoles", "stats"
        ]

        for field in updatable_fields:
            if field in data:
                if field == "stats":
                    # Merge stats instead of replacing
                    current_stats = company.get("stats", {})
                    current_stats.update(data["stats"])
                    update_data["stats"] = current_stats
                else:
                    update_data[field] = data[field]

        update_data["updatedAt"] = datetime.utcnow()

        # Update company
        db.companies.update_one(
            {"$or": [
                {"companyId": company_id},
                {"_id": ObjectId(company_id) if ObjectId.is_valid(
                    company_id) else None}
            ]},
            {"$set": update_data}
        )

        return jsonify({
            "success": True,
            "message": "Company updated successfully"
        }), 200

    except Exception as e:
        current_app.logger.error(f"Update company error: {str(e)}")
        return jsonify({"success": False, "message": "Internal server error"}), 500

# ========================= DELETE COMPANY =========================


@admin_bp.route("/admin/companies/<company_id>", methods=["DELETE"])
@jwt_required()
def delete_company(company_id):
    try:
        current_user = get_jwt_identity()

        # Check if user is admin
        if not is_admin(current_user):
            return jsonify({"success": False, "message": "Admin access required"}), 403

        db = current_app.config["MONGO_DB"]

        # Find and delete company
        result = db.companies.delete_one({
            "$or": [
                {"companyId": company_id},
                {"_id": ObjectId(company_id) if ObjectId.is_valid(
                    company_id) else None}
            ]
        })

        if result.deleted_count == 0:
            return jsonify({"success": False, "message": "Company not found"}), 404

        # Also delete associated experiences
        db.experiences.delete_many({
            "$or": [
                {"companyId": company_id},
                {"_id": ObjectId(company_id) if ObjectId.is_valid(
                    company_id) else None}
            ]
        })

        return jsonify({
            "success": True,
            "message": "Company deleted successfully"
        }), 200

    except Exception as e:
        current_app.logger.error(f"Delete company error: {str(e)}")
        return jsonify({"success": False, "message": "Internal server error"}), 500

# ========================= GET ALL COMPANIES (ADMIN) =========================


@admin_bp.route("/admin/companies", methods=["GET"])
@jwt_required()
def get_all_companies_admin():
    try:
        current_user = get_jwt_identity()

        # Check if user is admin
        if not is_admin(current_user):
            return jsonify({"success": False, "message": "Admin access required"}), 403

        db = current_app.config["MONGO_DB"]

        # Get query parameters
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 20))
        search = request.args.get('search', '')

        skip = (page - 1) * limit

        # Build query
        query = {}
        if search:
            query['$or'] = [
                {'name': {'$regex': search, '$options': 'i'}},
                {'location': {'$regex': search, '$options': 'i'}},
                {'tags': {'$in': [search]}}
            ]

        # Get companies with pagination
        companies_cursor = db.companies.find(query).sort(
            "createdAt", -1).skip(skip).limit(limit)
        total_companies = db.companies.count_documents(query)

        companies = []
        for company in companies_cursor:
            companies.append({
                "id": str(company.get("_id")),
                "companyId": company.get("companyId"),
                "name": company.get("name"),
                "logo": company.get("logo"),
                "description": company.get("description"),
                "location": company.get("location"),
                "experienceCount": company.get("experienceCount", 0),
                "rating": company.get("rating", 0),
                "createdAt": company.get("createdAt").isoformat() if company.get("createdAt") else None,
                "updatedAt": company.get("updatedAt").isoformat() if company.get("updatedAt") else None,
                "stats": company.get("stats", {})
            })

        return jsonify({
            "success": True,
            "companies": companies,
            "pagination": {
                "page": page,
                "limit": limit,
                "total": total_companies,
                "pages": (total_companies + limit - 1) // limit
            }
        }), 200

    except Exception as e:
        current_app.logger.error(f"Get admin companies error: {str(e)}")
        return jsonify({"success": False, "message": "Internal server error"}), 500

# ========================= GET COMPANY DETAILS (ADMIN) =========================


@admin_bp.route("/admin/companies/<company_id>", methods=["GET"])
@jwt_required()
def get_company_admin(company_id):
    try:
        current_user = get_jwt_identity()

        # Check if user is admin
        if not is_admin(current_user):
            return jsonify({"success": False, "message": "Admin access required"}), 403

        db = current_app.config["MONGO_DB"]

        # Find company
        company = db.companies.find_one({
            "$or": [
                {"companyId": company_id},
                {"_id": ObjectId(company_id) if ObjectId.is_valid(
                    company_id) else None}
            ]
        })

        if not company:
            return jsonify({"success": False, "message": "Company not found"}), 404

        # Get full company data
        company_data = {
            "id": str(company.get("_id")),
            "companyId": company.get("companyId"),
            "name": company.get("name"),
            "logo": company.get("logo"),
            "description": company.get("description"),
            "location": company.get("location"),
            "founded": company.get("founded"),
            "employees": company.get("employees"),
            "website": company.get("website"),
            "rating": company.get("rating", 0),
            "experienceCount": company.get("experienceCount", 0),
            "tags": company.get("tags", []),
            "stats": company.get("stats", {}),
            "jobRoles": company.get("jobRoles", []),
            "roundsAnalytics": company.get("roundsAnalytics", {}),
            "insights": company.get("insights", {}),
            "placedStudents": company.get("placedStudents", []),
            "createdAt": company.get("createdAt").isoformat() if company.get("createdAt") else None,
            "updatedAt": company.get("updatedAt").isoformat() if company.get("updatedAt") else None,
            "createdBy": company.get("createdBy")
        }

        return jsonify({
            "success": True,
            "company": company_data
        }), 200

    except Exception as e:
        current_app.logger.error(f"Get admin company error: {str(e)}")
        return jsonify({"success": False, "message": "Internal server error"}), 500

# ========================= ADD JOB ROLE =========================


@admin_bp.route("/admin/companies/<company_id>/job-roles", methods=["POST"])
@jwt_required()
def add_job_role(company_id):
    try:
        current_user = get_jwt_identity()

        if not is_admin(current_user):
            return jsonify({"success": False, "message": "Admin access required"}), 403

        data = request.get_json()

        required_fields = ["title", "avgPackage", "positions"]
        for field in required_fields:
            if field not in data:
                return jsonify({"success": False, "message": f"Missing required field: {field}"}), 400

        job_role = {
            "title": data["title"],
            "avgPackage": data["avgPackage"],
            "positions": data["positions"],
            "bondInfo": data.get("bondInfo", "No bond"),
            "requirements": data.get("requirements", [])
        }

        db = current_app.config["MONGO_DB"]

        # Add job role to company
        result = db.companies.update_one(
            {"$or": [
                {"companyId": company_id},
                {"_id": ObjectId(company_id) if ObjectId.is_valid(
                    company_id) else None}
            ]},
            {
                "$push": {"jobRoles": job_role},
                "$set": {"updatedAt": datetime.utcnow()}
            }
        )

        if result.modified_count == 0:
            return jsonify({"success": False, "message": "Company not found"}), 404

        return jsonify({
            "success": True,
            "message": "Job role added successfully"
        }), 200

    except Exception as e:
        current_app.logger.error(f"Add job role error: {str(e)}")
        return jsonify({"success": False, "message": "Internal server error"}), 500

# ========================= REMOVE JOB ROLE =========================


@admin_bp.route("/admin/companies/<company_id>/job-roles", methods=["DELETE"])
@jwt_required()
def remove_job_role(company_id):
    try:
        current_user = get_jwt_identity()

        if not is_admin(current_user):
            return jsonify({"success": False, "message": "Admin access required"}), 403

        data = request.get_json()

        if "title" not in data:
            return jsonify({"success": False, "message": "Missing job role title"}), 400

        db = current_app.config["MONGO_DB"]

        # Remove job role from company
        result = db.companies.update_one(
            {"$or": [
                {"companyId": company_id},
                {"_id": ObjectId(company_id) if ObjectId.is_valid(
                    company_id) else None}
            ]},
            {
                "$pull": {"jobRoles": {"title": data["title"]}},
                "$set": {"updatedAt": datetime.utcnow()}
            }
        )

        if result.modified_count == 0:
            return jsonify({"success": False, "message": "Company or job role not found"}), 404

        return jsonify({
            "success": True,
            "message": "Job role removed successfully"
        }), 200

    except Exception as e:
        current_app.logger.error(f"Remove job role error: {str(e)}")
        return jsonify({"success": False, "message": "Internal server error"}), 500
